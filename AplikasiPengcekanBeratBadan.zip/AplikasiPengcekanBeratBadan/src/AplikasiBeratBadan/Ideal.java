/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AplikasiBeratBadan;

public class Ideal {
  private double tb,bb,tot;
    private String info;
    
    public double getTot() {
        return tot = this.bb / (this.tb * this.tb);
    }

    public String getInfo() {
        return info;
    }

    public void setTb(double tb) {
        this.tb = tb /100;
    }

    public void setBb(double bb) {
        this.bb = bb;
    }
    
    void hasilInfo() {
        if (getTot() < 18.5) {
            this.info = "ANDA KURUS";
        }else if (getTot() < 24.9) {
            this.info = "ANDA IDEAL";
        }else if (getTot() < 29.9) {
            this.info = "ANDA GEMUK";
        }else if (getTot() > 30.0) {
            this.info = "ANDA OBESITAS";
        }
} 
}
